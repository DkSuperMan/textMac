//
//  ViewController.h
//  textMacPro
//
//  Created by jin on 15/5/15.
//  Copyright (c) 2015年 jinchen. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

